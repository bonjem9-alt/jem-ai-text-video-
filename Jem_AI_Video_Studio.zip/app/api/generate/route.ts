import { NextRequest, NextResponse } from 'next/server';
import RunwayML from '@runwayml/sdk';

export const runtime = 'nodejs';
const client = new RunwayML({ apiKey: process.env.RUNWAYML_API_SECRET });

export async function POST(req: NextRequest) {
  try {
    if (!process.env.RUNWAYML_API_SECRET) return NextResponse.json({error:'Server is missing RUNWAYML_API_SECRET.'},{status:500});
    const form = await req.formData();
    const mode = String(form.get('mode') || 'text');
    const prompt = String(form.get('prompt') || '').trim();
    const ratio = String(form.get('ratio') || '720:1280');
    const duration = Number(form.get('duration') || 5);
    if (!prompt) return NextResponse.json({error:'Prompt is required.'},{status:400});
    if (!['720:1280','1280:720','960:960'].includes(ratio)) return NextResponse.json({error:'Invalid aspect ratio.'},{status:400});
    if (![5,10].includes(duration)) return NextResponse.json({error:'Duration must be 5 or 10 seconds.'},{status:400});
    let task: {id:string};
    if (mode === 'photo') {
      const image = form.get('image');
      if (!(image instanceof File)) return NextResponse.json({error:'Photo is required.'},{status:400});
      if (image.size > 5*1024*1024) return NextResponse.json({error:'Image must be 5MB or smaller.'},{status:400});
      if (!['image/jpeg','image/png','image/webp'].includes(image.type)) return NextResponse.json({error:'Use JPG, PNG or WebP.'},{status:400});
      const bytes = Buffer.from(await image.arrayBuffer());
      const dataUri = `data:${image.type};base64,${bytes.toString('base64')}`;
      task = await client.imageToVideo.create({model:'gen4.5',promptImage:dataUri,promptText:prompt,ratio,duration});
    } else {
      task = await client.textToVideo.create({model:'gen4.5',promptText:prompt,ratio,duration});
    }
    return NextResponse.json({id:task.id});
  } catch (e) {
    const message = e instanceof Error ? e.message : 'Could not start generation.';
    return NextResponse.json({error:message},{status:500});
  }
}
